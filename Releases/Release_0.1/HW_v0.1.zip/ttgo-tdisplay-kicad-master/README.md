# TTGOESP32 
KICAD LIB and Footprint for the ESP TTGO Dev board

# Pinout 
![Pinout](TTGO_pinout.jpg)

# Footprint 
![Footprint](ttgo_display_v1.1_footprint.JPG)
